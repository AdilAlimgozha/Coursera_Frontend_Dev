const timesTwo = require('./timesTwo');

// Write the first test
test('returns ...', () => {
    expect().toBe()
});
